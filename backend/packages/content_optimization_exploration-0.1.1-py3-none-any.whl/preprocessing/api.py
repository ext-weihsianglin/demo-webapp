"""Importable retention-first parser for saved snapshots and ephemeral inputs."""
from preprocessing.adapters.local import extract_conservative, extract_markdown_text
from preprocessing.downstream import document
from preprocessing.quality import classify_payload, source_inventory
from preprocessing.schema import Snapshot, snapshot_identity

PARSER_REVISION = "3d4d35d3c32ac5b8c14983f99f92c2f633669417"


def parse_snapshot(payload, href, hostname="", *, source_format=None, source=None):
    """Return (document, chunks) using the existing inventory/adapters/selection.

    Source format may be supplied by a snapshot manifest or input form; otherwise
    it is classified using the existing heuristic. No query or label is accepted.
    The raw payload remains the caller's responsibility; no page is fetched or
    saved, and no evaluation-cache path is invented for an ephemeral input.
    """
    format_name = source_format if source_format is not None else classify_payload(payload)
    payload_hash, identity = snapshot_identity(payload, href)
    snapshot = Snapshot(identity, payload_hash, href, hostname, payload, format_name)
    inventory = source_inventory(payload, href, format_name)
    candidate = extract_conservative(snapshot) if format_name == "html" else extract_markdown_text(snapshot)
    provenance = {**(source or {}), "payload_hash": payload_hash, "href": href,
                  "hostname": hostname, "format": format_name}
    for key in ("source_file", "source_file_hash", "source_row"):
        provenance.setdefault(key, None)
    parsed, chunks = document(snapshot, provenance, [candidate.to_dict()], inventory)
    parsed["raw_payload_path"] = None
    parsed["raw_payload_reference"] = {key: provenance[key] for key in
                                     ("source_file", "source_file_hash", "source_row", "payload_hash")}
    parsed["candidate_diagnostics"] = candidate.diagnostics
    return parsed, chunks
