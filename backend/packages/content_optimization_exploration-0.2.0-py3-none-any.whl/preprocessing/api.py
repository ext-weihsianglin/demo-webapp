"""Tuple facade over the exact upstream corpus parser."""
from trad_ml_scorer.retention_features import parse_snapshot as _parse

PARSER_REVISION = "864e6634a54ad80ac1657129e994b18c3a1f7eff"

def parse_snapshot(payload, href, hostname="", *, source_format=None, source=None):
    doc = _parse(payload, href, hostname, source, source_format=source_format)
    doc["candidate_diagnostics"] = dict(doc.get("representation", {}))
    return doc, doc["chunks"]
