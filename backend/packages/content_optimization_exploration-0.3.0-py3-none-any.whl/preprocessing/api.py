"""Tuple facade over the exact upstream corpus parser modules."""
from preprocessing.adapters.local import extract_conservative, extract_markdown_text
from preprocessing.downstream import document
from preprocessing.quality import classify_payload, source_inventory
from preprocessing.schema import Snapshot, snapshot_identity
from scripts.analyze_content import words

PARSER_REVISION = "6a9606d3febaf62f76c8448c44f91a120107e5a6"

def parse_snapshot(payload, href, hostname="", *, source_format=None, source=None):
    payload_hash, identity = snapshot_identity(payload, href)
    format_name = source_format if source_format is not None else classify_payload(payload)
    snapshot = Snapshot(identity, payload_hash, href, hostname, payload, format_name)
    inventory = source_inventory(payload, href, format_name)
    candidate = extract_conservative(snapshot) if format_name == "html" else extract_markdown_text(snapshot)
    source = {**(source or {}), "payload_hash": payload_hash, "href": href,
              "hostname": hostname, "format": format_name}
    for key in ("source_file", "source_file_hash", "source_row"):
        source.setdefault(key, None)
    doc, chunks = document(snapshot, source, [candidate.to_dict()], inventory)
    doc["scorer_source_word_count"] = len(words(inventory["body_text"]))
    doc["raw_payload_path"] = None
    doc["raw_payload_reference"] = {key: source[key] for key in
                                    ("source_file", "source_file_hash", "source_row", "payload_hash")}
    doc["chunks"] = chunks
    doc["candidate_diagnostics"] = dict(doc.get("representation", {}))
    return doc, chunks
